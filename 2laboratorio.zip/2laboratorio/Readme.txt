Proyecto 2 - Robin Gonzalez

El proyecto se maneja mediante un Makefile sencillo

make: compila y ejecuta

make run: ejecuta

make clean: borra ejecutable

make help: muestra estas instrucciones
